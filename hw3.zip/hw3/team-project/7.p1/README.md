## CH7 Project 1



## exec

```sh
make build
make run
```

## screenshot

![result](https://imgur.com/50chGOy.png)